var app = require('./easypages');

// Views
new app.Page('/','views/index.html')
new app.Page('/cars','views/cars.html')
new app.Page('/cats','views/cats.html')
new app.Page('/cars/new','views/cars_form.html')
// Static Files
new app.Page('/static/style','stylesheets/style.css')
// Images
new app.Page('/media/carcat','images/cat-in-car.jpg')
new app.Page('/media/cat0','images/cats/happy_cat.jpg')
new app.Page('/media/cat1','images/cats/burrito.jpg')
new app.Page('/media/cat2','images/cats/floating.gif')
new app.Page('/media/cat3','images/cats/music.png')
new app.Page('/media/cat4','images/cats/trampoline.bmp')
new app.Page('/media/cat5','images/cats/fat_frolick.jpg')
new app.Page('/media/cat6','images/cats/skydiving.gif')
new app.Page('/media/cat7','images/cats/machine_gun.jpg')
new app.Page('/media/cat8','images/cats/half_tiger.png')
new app.Page('/media/car0','images/cars/chevy_X5.png')
new app.Page('/media/car1','images/cars/2018_Lambourghini.jpg')
new app.Page('/media/car2','images/cars/python.jpg')
new app.Page('/media/car3','images/cars/Mercedes_F105.jpg')
new app.Page('/media/car4','images/cars/Bugatti_F4.png')
new app.Page('/media/car5','images/cars/chrysler_fusion.png')
new app.Page('/media/car6','images/cars/Toyota_Ultimate_Fasion.bmp')
new app.Page('/media/car7','images/cars/200_s.gif')
// Errors
app['404'].file = 'views/notfound.html';

app.run(7077);